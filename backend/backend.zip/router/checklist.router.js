const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/checklist.controller');
const verifyToken = require('../middlewares/verifyToken');
const verifyRole  = require('../middlewares/verifyRole');

router.get('/',                           verifyToken, verifyRole(['Chef_chantier']), ctrl.getAll);
router.post('/',                           verifyToken, verifyRole(['Chef_chantier']),                      ctrl.create);
router.put('/:id',                         verifyToken, verifyRole(['Chef_chantier']),                      ctrl.update);
router.patch('/:id/tasks/:taskId/toggle',  verifyToken, verifyRole(['Chef_chantier']),        ctrl.toggleTask);
router.delete('/:id',                      verifyToken, verifyRole(['Chef_chantier']),                      ctrl.remove);

module.exports = router;
