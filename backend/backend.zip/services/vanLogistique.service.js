const vlConfig = require('../config/vanLogistique');

const toPlainRequest = (request) => {
  if (!request) return {};
  if (typeof request.get === 'function') return request.get({ plain: true });
  return { ...request };
};

const formatDateOnly = (value) => {
  if (value == null || value === '') return '';
  if (typeof value === 'string') return value.trim().slice(0, 10);
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  return String(value).trim().slice(0, 10);
};

const buildPayload = (request) => {
  const plain = toPlainRequest(request);
  const description = String(
    plain.needDescription || plain.equipmentRequested || '',
  ).trim();
  const date = formatDateOnly(plain.desiredDate);

  const payload = {
    description,
    date,
  };

  if (plain.ref) payload.correlationId = String(plain.ref);
  if (plain.id != null) payload.btpRequestId = plain.id;

  return payload;
};

const FETCH_TIMEOUT_MS = Number(process.env.VAN_LOGISTIQUE_TIMEOUT_MS) || 12_000;

const formatNetworkError = (err, url) => {
  const code = err.cause?.code || err.code || '';
  let host = '';
  try {
    host = new URL(url).hostname;
  } catch {
    /* ignore */
  }

  const isPrivate = /^(172\.|10\.|192\.168\.|127\.)/.test(host);

  if (code === 'UND_ERR_CONNECT_TIMEOUT' || /timeout/i.test(err.message)) {
    return [
      `Délai dépassé vers ${url}.`,
      'Ce n\'est pas un problème d\'autorisation CORS.',
      isPrivate
        ? 'Vérifiez : serveur logistique démarré, IP/port corrects dans VAN_LOGISTIQUE_URL (backend/.env), PC et logistique sur le même réseau Wi‑Fi.'
        : 'Vérifiez que l\'API logistique est en ligne et joignable depuis le serveur backend.',
    ].join(' ');
  }

  if (code === 'ECONNREFUSED') {
    return [
      `Connexion refusée vers ${url}.`,
      'Aucun service n\'écoute sur ce port (logistique arrêtée ou mauvais port).',
      host === '127.0.0.1' || host === 'localhost'
        ? 'Si la logistique tourne sur un autre appareil, remplacez localhost par son IP LAN dans backend/.env.'
        : '',
    ].filter(Boolean).join(' ');
  }

  if (isPrivate) {
    return [
      err.message,
      'IP privée : l\'envoi est fait par le backend Node (pas le navigateur).',
      'En dev : frontend via npm run dev (proxy → localhost:3001) et backend local démarré.',
      'Si l\'erreur persiste, la machine logistique est injoignable (IP hotspot changée, pare-feu, service arrêté).',
    ].join(' ');
  }

  return err.message;
};

const fetchWithTimeout = (url, init = {}) => {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  return fetch(url, { ...init, signal: controller.signal }).finally(() => clearTimeout(timer));
};

const authHeaders = (withJsonBody = false) => {
  const h = {};
  if (vlConfig.apiKey) h.Authorization = `Bearer ${vlConfig.apiKey}`;
  if (withJsonBody) h['Content-Type'] = 'application/json';
  return h;
};

const parseResponse = async (response) => {
  const text = await response.text();
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = { raw: text?.slice(0, 200) };
  }
  return { json, text };
};

const tryRequest = async ({ method, url, body }) => {
  const hasBody = body && !['GET', 'HEAD', 'DELETE'].includes(method);
  const init = {
    method,
    headers: authHeaders(hasBody),
  };
  if (hasBody) {
    init.body = JSON.stringify(body);
  }
  const response = await fetchWithTimeout(url, init);
  const { json, text } = await parseResponse(response);
  return {
    ok: response.ok,
    status: response.status,
    message: json.message || json.error || (text && text.slice(0, 120)) || null,
  };
};

exports.sendEquipmentRequest = async (request) => {
  const plain = toPlainRequest(request);
  const payload = buildPayload(request);

  if (!payload.description || payload.description.length < 10) {
    return {
      ok: false,
      error: 'Description manquante ou trop courte pour l\'envoi logistique',
    };
  }
  if (!payload.date) {
    return { ok: false, error: 'Date souhaitée manquante pour l\'envoi logistique' };
  }

  if (!vlConfig.isOutboundEnabled()) {
    const mockRef = `mock-vl-${request.id}-${Date.now()}`;
    console.log('[VAN LOGISTIQUE] Mode mock — demande simulée:', request.ref);
    return { ok: true, externalId: mockRef, reference: mockRef, mocked: true };
  }

  const url = vlConfig.getRequestUrl();
  if (!url) {
    return { ok: false, error: 'VAN_LOGISTIQUE_URL non définie dans backend/.env' };
  }

  try {
    console.log(
      `[VAN LOGISTIQUE] Envoi ${plain.ref || '(sans ref)'} → ${url}`,
      { description: payload.description.slice(0, 120), date: payload.date },
    );

    const response = await fetchWithTimeout(url, {
      method: 'POST',
      headers: authHeaders(true),
      body: JSON.stringify(payload),
    });

    const { json, text } = await parseResponse(response);

    if (!response.ok) {
      return {
        ok: false,
        error: json.message || json.error || `Erreur ${response.status}: ${text?.slice(0, 200)}`,
      };
    }

    const reference =
      json.reference ||
      json.data?.reference ||
      json.externalId ||
      json.id ||
      json.data?.id ||
      null;

    if (!reference) {
      return { ok: false, error: 'Réponse VAN Logistique sans reference' };
    }

    return { ok: true, externalId: String(reference), reference: String(reference) };
  } catch (err) {
    const msg = formatNetworkError(err, url);
    console.error('[VAN LOGISTIQUE] Erreur envoi:', msg, { ref: plain.ref, code: err.cause?.code || err.code });
    return { ok: false, error: msg };
  }
};

/**
 * Annule une solicitation — essaie plusieurs routes jusqu'à succès.
 */
exports.cancelEquipmentRequest = async (reference) => {
  if (!reference) {
    return { ok: false, error: 'Référence logistique manquante' };
  }

  if (!vlConfig.isOutboundEnabled()) {
    console.log('[VAN LOGISTIQUE] Mode mock — annulation simulée:', reference);
    return { ok: true, mocked: true };
  }

  const attempts = vlConfig.getCancelAttempts(reference);
  if (!attempts.length) {
    return { ok: false, error: 'Aucune URL d\'annulation configurée' };
  }

  const failures = [];

  for (const attempt of attempts) {
    try {
      console.log(`[VAN LOGISTIQUE] Annulation — ${attempt.label}: ${attempt.method} ${attempt.url}`);
      const result = await tryRequest(attempt);

      if (result.ok) {
        console.log(`[VAN LOGISTIQUE] Annulation OK (${attempt.label}) — ${reference}`);
        return { ok: true, via: attempt.label };
      }

      failures.push(`${attempt.label} → ${result.status}${result.message ? ` (${result.message})` : ''}`);

      if (![404, 405, 400].includes(result.status)) {
        break;
      }
    } catch (err) {
      failures.push(`${attempt.label} → ${err.message}`);
    }
  }

  const last = failures[0] || 'aucune réponse';
  return {
    ok: false,
    error: `Impossible d'annuler chez VAN Logistique (réf. ${reference}). ${last}`,
    details: failures.join(' | '),
  };
};

exports.isEnabled = () => vlConfig.isOutboundEnabled();

exports.getConfigHint = () => ({
  url: vlConfig.getRequestUrl() || '(non défini)',
  enabled: vlConfig.enabled,
  hasApiKey: Boolean(vlConfig.apiKey),
});
