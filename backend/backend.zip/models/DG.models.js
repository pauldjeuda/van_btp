const createRoleModel = require('./role.base.models');
module.exports = createRoleModel('PDG', 'pdgs');
